<html lang="ko">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width=1, initial-scale=1">
    <title>상품목록 페이지</title>
    <style>
      .fas{
        font-size: 24px;
        color: #9ecd53;
      }
      table.type10 {
  border-collapse: collapse;
  text-align: left;
  line-height: 1.5;
  border-top: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  margin: 20px 10px;
}
table.type10 th {
  width: 150px;
  padding: 10px;
  font-weight: bold;
  vertical-align: top;
  color: #fff;
  background: #e7708d;
  margin: 20px 10px;
}
table.type10 th {
  width: 150px;
  padding: 10px;
}
table.type10 td {
  width: 350px;
  padding: 10px;
  vertical-align: top;
}
table.type10 .even {
  background: #fdf3f5;
}
    </style>
  </head>
  <body>
  <h2>과일목록</h2>
  <p><a href="cart.php" title="장바구니"><i class="fas fa-cart-shopping"></i>장바구니</a></p>
  <table class="type10">
    <colgroup>
      <col width="200">
      <col width="80">
      <col width="140">
    </colgroup>
    <tr>
      <th>이름</th>
      <th>가격</th>
      <th>장바구니</th>
    </tr>
<?php
  include("./cart_product.inc");
  // while( list( $name ,$price ) =  each( $fruit ) ){
    foreach($fruit as $name => $price){
?>
  <form name="insert_form" method="post" 
  action="./cart.php?code=insert&name=<?=$name?>">
    <tr>
      <td> <?=$name?></td>
      <td><?=$price?> 원 </td>
      <td>
        <select name="amount">
          <option value=1>1</option>
          <option value=2>2</option>
          <option value=3>3</option>
          <option value=4>4</option>
          <option value=5>5</option>
        </select>
        <input type="submit" name="submit" value="선택">
      </td>
    </tr>
  </form>
<?PHP
  }
?>
  </table>
</body>
</html>