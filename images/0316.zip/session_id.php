<?php
  session_start();
?>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width=1, initial-scale=1">
    <title>db인증 - 쿠키와 세션</title>
  </head>
  <body>
    <h2>db인증 - 세션정보 출력하기</h2>
    <p>세션값은 <?php echo$_SESSION['php'];?></p>
  </body>
</html> 