<?php
  session_start();
  $session_value="naver";
  $_SESSION['php'] = $session_value;
?>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width=1, initial-scale=1">
    <title>db인증 - 쿠키와 세션</title>
  </head>
  <body>
    <h2>db인증 - 쿠키와 세션</h2>
    <p>세션(session) - 서버측에 저장되는 id번호로서 웹사이트에서 클라이언트가 로그인 접소기 다른 웹페이지를 방문하더라도 세션정보를 유지하여 로그인이 계속 유지될 수 있도록 하는 정보이다.</p>
    <ul>
      <li>session_start(); 세션생성하기</li>
      <li>unset(); 세션삭제하기</li>
      <li>session unset(); 모든 세션 삭제하기</li>
      <li>session_destroy(); 세션을 종료하기</li>
    </ul>
    <h3>세션생성하기</h3>
    <p>아래버튼을 누르면 세션정보가 생성이 됩니다.</p>
    <a href="./session_id.php" title="세션id만들기">클릭 시 세션정보가 생성됩니다.</a>
  </body>
</html> 