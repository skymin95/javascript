<?php 
    $cookie_name="myCookie";
    $cookie_value="쿠키생성하기";
    setcookie($cookie_name, $cookie_value, time()+60*60);
?>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width=1, initial-scale=1">
    <title>db인증 - 쿠키와 세션</title>
  </head>
  <body>
    <h2>db인증 - 쿠키와 세션</h2>
    <p>쿠키(cookie) - 클라이언트측에 저장되는 정보로서 key, value값으로 구성된다.</p>
    <p>쿠키정보는 '오늘하루 열지않음','아이디저장'기억시 많이 사용되며 웹사이트 이용자의 패턴분석시에도 활용된다.</p>
    <p>setcookie(key, value, 유효시간)</p>
    <h3>쿠키생성하기</h3>
    <p>아래버튼을 누르면 세션정보가 생성이 됩니다.</p>
    <a href="./cookie_id.php" title="쿠키정보 만들기">클릭 시 쿠키정보가 생성됩니다.</a>
  </body>
</html> 