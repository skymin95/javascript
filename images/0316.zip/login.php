<?php 
    //세션
    session_start();
    $_SESSION['userid']='jiaeyammas';
    $_SESSION['username']='홍길동';
    $userid = $_SESSION['userid']; //변수에 세션아이디를 저장
    $username = $_SESSION['username']; //변수에 세션이름를 저장
?>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="device-width=1, initial-scale=1">
    <title>db인증 - 쿠키와 세션</title>
  </head>
  <body>
    <h2>로그인</h2>
    <p>등록하신 아이디는 <?=$userid?> 입니다.</p>
    <p>등록하신 이름은 <?=$username?> 입니다.</p>

</html> 